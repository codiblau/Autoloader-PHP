<?php

class Class1 {

    public function demo(){
        echo "Class 1 was loaded correctly!";
    }

}

?>
